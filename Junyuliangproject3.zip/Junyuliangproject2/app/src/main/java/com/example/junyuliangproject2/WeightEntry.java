package com.example.junyuliangproject2;

public class WeightEntry {
    public int id;
    public String date;
    public float weight;

    public WeightEntry(int id, String date, float weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }
}
