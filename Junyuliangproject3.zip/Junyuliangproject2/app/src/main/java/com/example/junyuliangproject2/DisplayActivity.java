package com.example.junyuliangproject2;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DisplayActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1001; // Request code for SMS permission

    // UI elements
    private EditText editDate;
    private EditText editWeight;
    private Button btnAddWeight;
    private RecyclerView weightRecyclerView;

    // Data handling
    private ArrayList<WeightEntry> weightList;
    private WeightAdapter adapter;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        // Ask for SMS permission
        requestSmsPermission();

        // Initialize UI components
        editDate = findViewById(R.id.editDate);
        editWeight = findViewById(R.id.editWeight);
        btnAddWeight = findViewById(R.id.btnAddWeight);
        weightRecyclerView = findViewById(R.id.weightRecyclerView);

        // Set up database and RecyclerView
        databaseHelper = new DatabaseHelper(this);
        weightList = new ArrayList<>();
        adapter = new WeightAdapter(this, weightList, databaseHelper);

        weightRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        weightRecyclerView.setAdapter(adapter);

        // Load existing data into RecyclerView
        loadWeightEntries();

        // Set up button to add weight entry and send SMS if allowed
        btnAddWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = editDate.getText().toString();
                String weightInput = editWeight.getText().toString();

                // Validate input
                if (date.isEmpty() || weightInput.isEmpty()) {
                    Toast.makeText(DisplayActivity.this, "Please enter both date and weight.", Toast.LENGTH_SHORT).show();
                    return;
                }

                float weight = Float.parseFloat(weightInput);
                boolean inserted = databaseHelper.insertWeight(date, weight);
                if (inserted) {
                    Toast.makeText(DisplayActivity.this, "Entry added.", Toast.LENGTH_SHORT).show();
                    sendSMS("You've logged a new weight: " + weight + "kg on " + date);
                    loadWeightEntries();
                } else {
                    Toast.makeText(DisplayActivity.this, "Failed to add entry.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Request SEND_SMS permission at runtime
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    // Sends an SMS message if permission is granted
    private void sendSMS(String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("1234567890", null, message, null, null); // Replace with actual number
        }
    }

    // Load weight entries from the database into the list and update RecyclerView
    private void loadWeightEntries() {
        weightList.clear();
        Cursor cursor = databaseHelper.getAllWeights();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String date = cursor.getString(1);
                float weight = cursor.getFloat(2);
                weightList.add(new WeightEntry(id, date, weight));
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    // Handle the user's response to the SMS permission prompt
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied. Notifications disabled.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
