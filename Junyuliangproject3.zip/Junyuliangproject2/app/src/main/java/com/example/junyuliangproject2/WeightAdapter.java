package com.example.junyuliangproject2;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {

    private Context context;
    private ArrayList<WeightEntry> weightList;
    private DatabaseHelper dbHelper;

    public WeightAdapter(Context context, ArrayList<WeightEntry> weightList, DatabaseHelper dbHelper) {
        this.context = context;
        this.weightList = weightList;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.weight_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightEntry entry = weightList.get(position);
        holder.textDate.setText(entry.date);
        holder.textWeight.setText(String.valueOf(entry.weight));

        // Handle delete
        holder.deleteButton.setOnClickListener(v -> {
            boolean deleted = dbHelper.deleteWeight(entry.id);
            if (deleted) {
                weightList.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, weightList.size());
                Toast.makeText(context, "Deleted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Delete failed", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle update
        holder.itemView.setOnClickListener(v -> {
            showUpdateDialog(entry, position);
        });
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    private void showUpdateDialog(WeightEntry entry, int position) {
        View dialogView = LayoutInflater.from(context).inflate(R.layout.activity_display, null);
        EditText inputDate = new EditText(context);
        inputDate.setText(entry.date);
        EditText inputWeight = new EditText(context);
        inputWeight.setText(String.valueOf(entry.weight));

        AlertDialog dialog = new AlertDialog.Builder(context)
                .setTitle("Update Entry")
                .setMessage("Edit the values:")
                .setView(dialogView)
                .setPositiveButton("Update", (dialog1, which) -> {
                    String newDate = inputDate.getText().toString();
                    float newWeight = Float.parseFloat(inputWeight.getText().toString());

                    boolean updated = dbHelper.updateWeight(entry.id, newDate, newWeight);
                    if (updated) {
                        entry.date = newDate;
                        entry.weight = newWeight;
                        notifyItemChanged(position);
                        Toast.makeText(context, "Updated", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .create();
        dialog.show();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textDate, textWeight;
        Button deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textDate = itemView.findViewById(R.id.textDate);
            textWeight = itemView.findViewById(R.id.textWeight);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }

    }
}
